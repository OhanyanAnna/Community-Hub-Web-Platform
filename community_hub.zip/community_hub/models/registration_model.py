from app import db

class Registration(db.Model):
    __tablename__ = 'registrations'
    id = db.Column(db.Integer, primary_key=True)
    activity_id = db.Column(db.Integer, db.ForeignKey('activities.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    contact_info = db.Column(db.String(200), nullable=False)
    preferred_time = db.Column(db.String(100), nullable=True)
    special_needs = db.Column(db.String(200), nullable=True)
    activity = db.relationship('Activity', backref='registrations')

    def __repr__(self):
        return f"<Registration {self.name} for {self.activity.title}>"
